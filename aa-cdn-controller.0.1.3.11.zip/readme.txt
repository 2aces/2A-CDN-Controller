=== 2Ace's CDN Controller ===
Contributors: celsobessa
Donate link: http://www.2aces.com.br/wordpress/cnd-77-controler/
Tags: cdn, CDN77, W3TC, Web Optimization, Pagespeed, optimization
Requires at least: 3.0.1
Tested up to: 3.6
Stable tag: 0.1.1.9
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A simple plugin to control CDN resources. The first release supports CDN77, with other CDN providers support coming soon.

== Description ==

This plugin gives you control to your CDN resources. It's intended for those not using W3TC cache CDN functionality or those using CDNs not supported by W3TC. The initial release supports only the Purge All action to CDN77's API, but other actions and CDN providers will be added soon.

This is an experimental plugin and relies on third party services. It's free to use AS IS, and this means that you we do not provide specific support, although we try to do our best on Wordpress Community Support Forum. Yet, if it's being useful to you, considerate telling the world about it. Just publish a post, a tweet or status update pointing to www.2aces.com.br/wordpress/2aces-cdn-controler

Thanks!

== Installation ==

1. Upload `aa-cdn-controller` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

No frequent question yet.

== Screenshots ==

== Changelog ==

= 0.1.3.11 =
* Initial Release

== Roadmap ==

0.2.3.0 - Add Purge File and  Prefetch options on CDN77; Adminbar menu
0.2.3.5 - Add Get Stats and Get CDN Details on CDN77
0.3.3.0 - Support to Amazon Cloudfront
0.3.3.0 - Support to MaxCDN
0.3.3.0 - Support to NetDNA
