<?php
/**
 * CDN77 Controller Admin page
 *
 * @author      2Aces Conte&uacute;do e Estrat&eacute;gia
 * @package     2Aces CDN Controller
 * @version     0.1.3.11
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly